package com.example.chathive.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
