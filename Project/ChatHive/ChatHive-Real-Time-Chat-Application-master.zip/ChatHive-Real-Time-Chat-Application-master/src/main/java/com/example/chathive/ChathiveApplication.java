package com.example.chathive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChathiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChathiveApplication.class, args);
	}

}
